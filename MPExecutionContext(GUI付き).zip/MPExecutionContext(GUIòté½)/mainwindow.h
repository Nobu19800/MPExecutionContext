
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QList>
#include <QMainWindow>
#include <QSlider>

#include "SetComp.h"
#include "MPComp.h"
#include "MPExecutionContext.h"

class DiagramScene;

QT_BEGIN_NAMESPACE
class QAction;
class QToolBox;
class QSpinBox;
class QComboBox;
class QFontComboBox;
class QButtonGroup;
class QLineEdit;
class QGraphicsTextItem;
class QFont;
class QToolButton;
class QAbstractButton;
class QGraphicsView;
class QPushButton;
QT_END_NAMESPACE

/*���C���E�B���h�E*/

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
	MainWindow(RTC::MPExecutionContext *ec);
   void UpdateRTC(std::vector<Rule> &rs);
   RTC::MPExecutionContext *m_ec;

private slots:
	void UpdateComp();
	void m_resize(int w, int h);
	bool save();
	void open();
	void newFile();

protected:


private:
	SetComp *SC;
	QPushButton *UB;
	void createMenus();
	void createAction();
	QAction *newAct;
	QAction *openAct;
	QAction *saveAct;
	QWidget *widget;

	QMenu *fileMenu;

	QTextCodec* tc;
	



};

#endif
