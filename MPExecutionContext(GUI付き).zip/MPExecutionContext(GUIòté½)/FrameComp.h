
#ifndef FRAMECOMP_H
#define FRAMECOMP_H

#define SEL 0
#define PAL 1

#include "ExComp.h"

#include <QWidget>
#include <QGraphicsScene>
#include <QGraphicsItem>

#include <rtm/CorbaNaming.h>
#include <rtm/RTObject.h>
#include <rtm/CorbaConsumer.h>
#include <assert.h>
#include <string>
#include <vector>
#include <QBasicTimer>

#include "SetComp.h"
#include "AddButton.h"
#include "AddButton2.h"
#include "AddButton3.h"
#include "MPComp.h"

#include "MPExecutionContext.h"

#include "Config.h"


QT_BEGIN_NAMESPACE
class QGraphicsSceneMouseEvent;
class QMenu;
class QPointF;
class QGraphicsLineItem;
class QFont;
class QGraphicsTextItem;
class QColor;
class QPushButton;
class QHBoxLayout;
class QVBoxLayout;
class QTimeLine;
QT_END_NAMESPACE


class SetComp;





class FrameComp : public QWidget
{
	Q_OBJECT
public:
	
    FrameComp(RTC::MPExecutionContext *ec, SetComp *sc, QWidget *parent = 0);
	void AddComp(FEComp *FC);
	void InsertComp(int num, FEComp *FC);
	void UpdateSize();
	bool save(std::ofstream &ofs2, std::vector<main_Rule> &mR);
	bool open(std::vector<std::string> &Str, int &an, std::vector<main_Rule> &mR);
	bool openb(std::ifstream &ifs, std::vector<main_Rule> &mR);
	void UpdateRTC(std::vector<Rule> &rs);
	RTC::MPExecutionContext *m_ec;
	void newFile();
	Configs *cf;
	int X;
	int Y;
	std::vector<CompLayout *> Comps;
	void UpdateComp2(std::vector<std::string> rtclist, std::vector<CORBA::Object_ptr> rtclist2);
	void SetFrame(main_Rule &mR);

signals:
	void UpdateSizeSignal();

	






public slots:
   void AddCompSlot(ExComp *ec, FEComp *fc);
   void AddCompSlot1(FEComp *fc);
   void AddCompSlot2(CompLayout *c);
   void AddCompSlot3(CompLayout *c);
   void AddComps2();
   void InsertComps2(int num);
   void AddCompsT();
   void AddCompsU(CompLayout *c);
   void DeleteComp(QWidget *Vl, CompLayout *c);
   void UpdateEC(std::vector<Rule> &rs);
   void DeleteFrame();
   

   



protected:
	
    
private:
	std::vector<FEComp *> CLS;
	QTextCodec* tc;

	QVBoxLayout *mainLayout;
	
	
	

	
	

	

	

	SetComp *Sc;

	




};


#endif
