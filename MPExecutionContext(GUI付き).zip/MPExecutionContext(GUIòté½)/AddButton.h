#ifndef ADDBUTTON_H
#define ADDBUTTON_H

#include "ExComp.h"

#include <QWidget>
#include <QGraphicsScene>
#include <QGraphicsItem>



QT_BEGIN_NAMESPACE
class QGraphicsSceneMouseEvent;
class QMenu;
class QPointF;
class QGraphicsLineItem;
class QFont;
class QGraphicsTextItem;
class QColor;
class QPushButton;
class QHBoxLayout;
class QVBoxLayout;
QT_END_NAMESPACE


class AddButton : public QWidget
{
	Q_OBJECT
public:
	AddButton(QString text,QWidget *parent = 0);
	FEComp *Fc;
	QPushButton *PB;

signals:
	void clicked(FEComp *fc);

public slots:
	void clickedSlot();

};

#endif