
#ifndef SETCOMP_H
#define SETCOMP_H

#include <QWidget>
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QTabWidget>

#include "ExComp.h"
#include "FrameComp.h"
#include "FEComp.h"
#include "MPComp.h"

#include "MPExecutionContext.h"



QT_BEGIN_NAMESPACE
class QGraphicsSceneMouseEvent;
class QMenu;
class QPointF;
class QGraphicsLineItem;
class QFont;
class QGraphicsTextItem;
class QColor;
class QTabWidget;
QT_END_NAMESPACE

class FrameComp;



class SetComp : public QTabWidget
{
	Q_OBJECT
public:
	
    SetComp(RTC::MPExecutionContext *ec, QWidget *parent = 0);
	void UpdateComp();
	void UpdateRTC(std::vector<Rule> &rs);
	RTC::MPExecutionContext *m_ec;
	void newFile();
	void DeleteComp(FrameComp *fc);
	std::vector<std::string> rtclist;
	std::vector<CORBA::Object_ptr> rtclist2;
	
	
signals:
	void UpdateSizeSignal(int w, int h);


public slots:
	void UpdateSizeSlot();
	bool save(const char *Name);
	bool open(const char *Name);
	void CreateComp();
	void UpdateEC();
	void UpdateComps();
	void UpdateComp2();
	
	


protected:
    
private:
	std::vector<FrameComp *> FCS;
	QTextCodec* tc;
	QTimer *time;

	

	




};


#endif
