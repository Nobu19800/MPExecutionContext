#ifndef COMPSEARCH_H
#define COMPSEARCH_H

#include <stdio.h>
#include <tchar.h>

#include <iostream>
#include <rtm/CorbaNaming.h>
#include <rtm/RTObject.h>
#include <rtm/CorbaConsumer.h>
#include <assert.h>
#include <string>
#include <vector>

void WriteString(std::string a, std::ofstream &ofs);
std::string ReadString(std::ifstream &ifs);

#endif