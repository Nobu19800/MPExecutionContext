#ifndef MPCOMP_H
#define MPCOMP_H
#include <rtm/RTC.h>
#include <rtm/Manager.h>
#include <rtm/PeriodicExecutionContext.h>

#include <vector>



class add_Rule
{
public:
	add_Rule(){};
	int state;
	std::string name;
	RTC::LightweightRTObject_var r;
};

class sub_Rule
{
public:
	sub_Rule(){};
	std::string v;
	RTC::LightweightRTObject_var r;
	int s;
};

class Rule
{
private:
    
public:
	std::vector<std::vector<sub_Rule>> SR;
	Rule(){};
	~Rule(){};
    
};

class main_Rule
{
public:
	main_Rule(){};
	std::vector<Rule> rs;
	std::vector<add_Rule> ar;
	
};

bool LoadMainRule(std::vector<main_Rule> &rs);
void LoadAddRule(std::vector<std::string> &cs, int &nm, std::vector<add_Rule> &ar);
void LoadSubRule(std::vector<std::string> &cs, int &nm, std::vector<sub_Rule> &sr);
void LoadHRule(std::vector<std::string> &cs, int &nm, std::vector<Rule> &rs);
void LoadSRule(std::vector<std::string> &cs, int &nm, Rule &r);
bool AddCount(std::vector<std::string> &cs, int &nm);

std::string Replace( std::string String1, std::string String2, std::string String3 );

#endif