#include "MPTask.h"


MPTask::MPTask(RTC::MPExecutionContext *c)
{
	m_ec = c;
}

void MPTask::addComp(RTC::LightweightRTObject_var c, int I, int J, int K)
{
	MPComp mc;
	mc.comp = c;
	mc.I = I;
	mc.J = J;
	mc.K = K;
	m_comp.push_back(mc);
	
}

int MPTask::svc()
{
	if(m_ec->rs.size() > m_ec->r_num)
	{
		for(int i=0;i < m_comp.size();i++)
		{
			m_ec->workerComp(m_comp[i].comp);
			
		}
	}

	return 0;
}


