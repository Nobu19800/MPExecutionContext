#ifndef MPTASK_H
#define MPTASK_H

#include <rtm/RTC.h>



#include <rtm/Manager.h>
#include <rtm/PeriodicExecutionContext.h>


#include "MPExecutionContext.h"




class MPComp
{
public:
	MPComp(){};
	RTC::LightweightRTObject_var comp;
	int I;
	int J;
	int K;
};

class MPTask : public virtual coil::Task
{
public:
		MPTask(RTC::MPExecutionContext *c);
		virtual int svc();
		void addComp(RTC::LightweightRTObject_var c, int I, int J, int K);
private:
	std::vector<MPComp> m_comp;
	RTC::MPExecutionContext *m_ec;

};




#endif
