#ifndef RTC_MPEXECUTIONCONTEXT_H
#define RTC_MPEXECUTIONCONTEXT_H

#include <rtm/RTC.h>



#include <rtm/Manager.h>
#include <rtm/PeriodicExecutionContext.h>

#include "MPComp.h"


#ifdef WIN32
#pragma warning( disable : 4290 )
#endif

class MPTask;
class GUITask;

namespace RTC
{

  class MPExecutionContext
    : public virtual PeriodicExecutionContext
  {

  public:

    MPExecutionContext();

    virtual ~MPExecutionContext(void);

    virtual int svc(void);

	void workerComp(RTC::LightweightRTObject_var c);

	std::vector<main_Rule> rs;

	void LoadRule();

	

	std::string getCompName(int num);
	int getCompNum();

	void LoadRuleGUI(std::vector<main_Rule> &RS_d);
	void LoadRules();

	int r_num;

	//std::vector<Comp> s_comp;

	

	



  };
};

#ifdef WIN32
#pragma warning( default : 4290 )
#endif


extern "C"
{
  DLL_EXPORT void MPExecutionContextInit(RTC::Manager* manager);
};

#endif
